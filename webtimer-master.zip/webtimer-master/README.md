## Web Timer

Web Timer is a Chrome extension designed to help you keep track of how
you're using your time online.

Check it out in the [Chrome Web Store](http://webtimerapp.com)!
